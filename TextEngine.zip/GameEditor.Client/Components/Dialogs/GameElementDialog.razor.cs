﻿using GameEditor.Client.Services;
using GameModel.Models;
using Microsoft.AspNetCore.Components;
using Radzen;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace GameEditor.Client.Components.Dialogs;

public partial class GameElementDialog : ComponentBase
{
    // -------- Query parameters --------
    [Parameter]
    [SupplyParameterFromQuery(Name = "id")]
    public string? QId { get; set; }

    [Parameter]
    [SupplyParameterFromQuery(Name = "mode")]
    public string? QMode { get; set; }

    // -------- Services / DI --------
    [Inject] public IGamePackService GamePackService { get; set; } = default!;
    [Inject] public NavigationManager Nav { get; set; } = default!;
    [Inject] public DialogService DialogService { get; set; } = default!;
    [Inject] public NotificationService Notifications { get; set; } = default!;

    private GamePack Pack => GamePackService.Current;

    // -------- UI state --------
    protected string? _error;
    protected bool _isDirty;
    protected bool _isNew;

    protected string _mode = "edit";          // normalized mode
    protected string _modeDisplay => _mode.ToUpperInvariant();

    protected string _type = "scene";         // scene | item | npc | player
    protected string _typeTitle = "Scene";
    protected string _key = "";
    protected string _title = "Edit";

    // Active working copy & original
    protected IGameElement? _edit;
    protected IGameElement? _original;

    // -------- Lifecycle --------
    protected override Task OnParametersSetAsync()
    {
        try
        {
            _error = null;
            ParseQuery();
            Load();
            _title = _mode switch
            {
                "new" => $"New {_typeTitle} · {_key}",
                "clone" => $"Clone {_typeTitle} · {_key}",
                _ => $"Edit {_typeTitle} · {_key}"
            };
        }
        catch (Exception ex)
        {
            _error = ex.Message;
        }
        return Task.CompletedTask;
    }

    private void ParseQuery()
    {
        _mode = (QMode ?? "edit").Trim().ToLowerInvariant();

        var id = (QId ?? "").Trim();
        if (string.IsNullOrWhiteSpace(id) || !id.Contains(':'))
            throw new InvalidOperationException("Missing or invalid id. Expected '?id={type}:{key}'.");

        var parts = id.Split(':', 2, StringSplitOptions.RemoveEmptyEntries);
        _type = parts[0].Trim().ToLowerInvariant();
        _key = parts[1].Trim();

        _typeTitle = _type switch
        {
            "scene" => "Scene",
            "item" => "Item",
            "npc" => "NPC",
            "player" => "Player",
            _ => throw new InvalidOperationException($"Unknown type '{_type}'.")
        };

        if (_mode is not ("new" or "edit" or "clone")) _mode = "edit";
        _isNew = _mode is "new" or "clone";
    }

    private void Load()
    {
        switch (_type)
        {
            case "scene": LoadTyped<Scene>(_key); break;
            case "item": LoadTyped<Item>(_key); break;
            case "npc": LoadTyped<Npc>(_key); break;
            case "player": LoadPlayer(_key); break;
            default: throw new InvalidOperationException($"Unknown type '{_type}'.");
        }
    }

    private void LoadTyped<T>(string key) where T : class, IGameElement, new()
    {
        var src = GetFromPack<T>(_type, key.Replace($"{_type}:",string.Empty));

        if (_mode == "new")
        {
            _original = null;
            _edit = new T
            {
                Id = key,
                Name = ToTitle(key),
                Description = "",
                IsVisible = true,
                States = new(),
                Attributes = new(),
                Flags = new(),
                Properties = new()
            };
        }
        else if (_mode == "clone")
        {
            if (src is null) throw new InvalidOperationException($"{_typeTitle}:{key} not found to clone.");
            _original = src;
            _edit = DeepClone(src);
            _edit!.Id = key; // new id from query
            _isDirty = true;
        }
        else // edit
        {
            if (src is null) throw new InvalidOperationException($"{_typeTitle}:{key} not found.");
            _original = src;
            _edit = DeepClone(src);
        }
    }

    private void LoadPlayer(string key)
    {
        var useMain = string.Equals(key, "main", StringComparison.OrdinalIgnoreCase)
                   || string.Equals(key, "player", StringComparison.OrdinalIgnoreCase);

        Player? src = useMain
            ? Pack.Player
            : (Pack.Players.TryGetValue(key, out var p) ? p : null);

        if (_mode == "new")
        {
            _original = null;
            _edit = new Player
            {
                Id = key,
                Name = ToTitle(key),
                Description = "",
                IsVisible = true,
                States = new(),
                Attributes = new(),
                Flags = new(),
                Properties = new()
            };
        }
        else if (_mode == "clone")
        {
            if (src is null) throw new InvalidOperationException($"Player:{key} not found to clone.");
            _original = src;
            _edit = DeepClone(src);
            _edit!.Id = key;
            _isDirty = true;
        }
        else
        {
            if (src is null) throw new InvalidOperationException($"Player:{key} not found.");
            _original = src;
            _edit = DeepClone(src);
        }
    }

    // -------- Save / Delete / Cancel --------
    protected Task SaveAsync()
    {
        if (_edit is null) return Task.CompletedTask;

        if (string.IsNullOrWhiteSpace(_key) || !Regex.IsMatch(_key, "^[a-z0-9-]+$"))
        {
            Notifications.Notify(NotificationSeverity.Warning, "Invalid Id",
                "Use lowercase letters, digits, hyphens only.");
            return Task.CompletedTask;
        }

        _edit.Id = _key;

        switch (_type)
        {
            case "scene":
                UpsertInto(Pack.Scenes, (Scene)_edit, _original as Scene);
                break;
            case "item":
                UpsertInto(Pack.Items, (Item)_edit, _original as Item);
                break;
            case "npc":
                UpsertInto(Pack.Npcs, (Npc)_edit, _original as Npc);
                break;
            case "player":
                var useMain = string.Equals(_key, "main", StringComparison.OrdinalIgnoreCase)
                           || string.Equals(_key, "player", StringComparison.OrdinalIgnoreCase);
                if (useMain)
                {
                    Pack.Player = DeepClone((Player)_edit);
                }
                else
                {
                    UpsertInto(Pack.Players, (Player)_edit, _original as Player);
                }
                break;
            default:
                throw new InvalidOperationException($"Unknown type '{_type}'.");
        }

        _isDirty = false;
        CloseOrNavigate(_edit);
        return Task.CompletedTask;
    }

    protected Task DeleteAsync()
    {
        if (_isNew || string.IsNullOrEmpty(_key)) return Task.CompletedTask;

        switch (_type)
        {
            case "scene": Pack.Scenes.Remove(_key); break;
            case "item": Pack.Items.Remove(_key); break;
            case "npc": Pack.Npcs.Remove(_key); break;
            case "player":
                var isMain = string.Equals(_key, "main", StringComparison.OrdinalIgnoreCase)
                          || string.Equals(_key, "player", StringComparison.OrdinalIgnoreCase);
                if (isMain)
                {
                    Notifications.Notify(NotificationSeverity.Warning, "Protected",
                        "The main Player cannot be deleted here.");
                    return Task.CompletedTask;
                }
                Pack.Players.Remove(_key);
                break;
        }

        CloseOrNavigate(result: null, deleted: true);
        return Task.CompletedTask;
    }

    protected void Cancel()
    {
        if (_isDirty)
            Notifications.Notify(NotificationSeverity.Info, "Canceled", "Your changes were not saved.");
        CloseOrNavigate(null);
    }

    private void CloseOrNavigate(IGameElement? result, bool deleted = false)
    {
        try
        {
            DialogService.Close(result);
            return;
        }
        catch
        {
            // not in a dialog, fall through to navigate
        }

        Nav.NavigateTo("/editor");
    }

    // -------- Pack helpers --------
    private static void UpsertInto<T>(Dictionary<string, T> dict, T updated, T? original)
        where T : class, IGameElement
    {
        var newKey = updated.Id;

        // handle rename (remove old key)
        if (original is not null && !string.Equals(original.Id, newKey, StringComparison.Ordinal))
        {
            dict.Remove(original.Id);
        }

        dict[newKey] = DeepClone(updated);
    }

    private T? GetFromPack<T>(string type, string key) where T : class, IGameElement
        => type switch
        {
            "scene" => Pack.Scenes.TryGetValue(key, out var s) ? s as T : null,
            "item" => Pack.Items.TryGetValue(key, out var i) ? i as T : null,
            "npc" => Pack.Npcs.TryGetValue(key, out var n) ? n as T : null,
            "player" => (string.Equals(key, "main", StringComparison.OrdinalIgnoreCase)
                         || string.Equals(key, "player", StringComparison.OrdinalIgnoreCase))
                        ? Pack.Player as T
                        : (Pack.Players.TryGetValue(key, out var p) ? p as T : null),
            _ => null
        };

    private static string ToTitle(string key)
        => string.Join(' ', key.Split('-', StringSplitOptions.RemoveEmptyEntries)
                               .Select(s => char.ToUpperInvariant(s[0]) + s[1..]));

    private static T DeepClone<T>(T obj)
        => JsonSerializer.Deserialize<T>(JsonSerializer.Serialize(obj))!;

    // -------- Type-specific section (swap with real editors when ready) --------
    protected RenderFragment TypeSection() => _type switch
    {
        "scene" => SceneSection(),
        "item" => ItemSection(),
        "npc" => NpcSection(),
        "player" => PlayerSection(),
        _ => builder => builder.AddMarkupContent(0, "<div>Unknown type.</div>")
    };

    protected RenderFragment SceneSection() => builder =>
    {
        var i = 0;
        builder.AddMarkupContent(i++, "<div class='rz-text-secondary rz-mb-2'>Scene-specific editor</div>");
        // TODO: replace with your Scene editor component
    };

    protected RenderFragment ItemSection() => builder =>
    {
        var i = 0;
        builder.AddMarkupContent(i++, "<div class='rz-text-secondary rz-mb-2'>Item-specific editor</div>");
        // TODO: replace with your Item editor component
    };

    protected RenderFragment NpcSection() => builder =>
    {
        var i = 0;
        builder.AddMarkupContent(i++, "<div class='rz-text-secondary rz-mb-2'>NPC-specific editor</div>");
        // TODO: replace with your NPC editor component
    };

    protected RenderFragment PlayerSection() => builder =>
    {
        var i = 0;
        builder.AddMarkupContent(i++, "<div class='rz-text-secondary rz-mb-2'>Player-specific editor</div>");
        // TODO: replace with your Player editor component
    };
}

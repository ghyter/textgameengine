# textgameengine
Engine to support a browser based text adventure game.

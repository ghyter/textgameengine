namespace GameModel.Models;

public class Npc: GameElement
{
    
}

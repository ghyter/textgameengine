using System;

namespace GameModel.Models;

public class Item : GameElement
{

}

using System.Text.Json.Serialization;

namespace GameModel.Models;


public class Player : GameElement
{

    
    //public int HitPoints { 
    //    get {
    //        if (!Attributes.TryGetValue("HitPoints", out int hitpoints))
    //        {
    //            Attributes["HitPoints"] = 10;
    //            hitpoints = 10;
    //        } 
    //        return hitpoints;
    //    }
    //    set => Attributes["HitPoints"] = value;
    // }

    
    //public int ArmorClass { 
    //    get {
    //        if (!Attributes.TryGetValue("ArmorClass", out int hitpoints))
    //        {
    //            Attributes["ArmorClass"] = 10;
    //            hitpoints = 10;
    //        }
    //        return hitpoints;
    //    }
    //    set => Attributes["ArmorClass"] = value;
    // }

}
